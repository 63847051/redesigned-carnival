#!/bin/bash
# =============================================================================
# PAI 可视化仪表板生成器
# =============================================================================
# 功能：生成可视化仪表板 HTML
# 使用：定期运行以更新可视化数据
# =============================================================================

PAI_DIR="/root/.openclaw/workspace/.pai-learning"
DASHBOARD_DIR="/root/.openclaw/workspace/public/pai-dashboard"
DASHBOARD_FILE="$DASHBOARD_DIR/index.html"

# 创建目录
mkdir -p "$DASHBOARD_DIR"
mkdir -p "$PAI_DIR/signals"

echo "🎨 生成 PAI 可视化仪表板..."

# 检查是否有数据
SIGNAL_FILES=($(ls "$PAI_DIR"/signals/*.jsonl 2>/dev/null))
if [ ${#SIGNAL_FILES[@]} -eq 0 ]; then
    echo "⚠️  还没有学习信号数据"
    # 生成空仪表板
    cat > "$DASHBOARD_FILE" <<'EOF'
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAI 学习仪表板</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .header {
            background: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .header h1 {
            color: #667eea;
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        .header p {
            color: #666;
            font-size: 1.1em;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card h3 {
            color: #666;
            font-size: 0.9em;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .stat-card .value {
            font-size: 2.5em;
            font-weight: bold;
            color: #667eea;
        }
        .chart-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .chart-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .chart-card h2 {
            color: #667eea;
            margin-bottom: 20px;
            font-size: 1.3em;
        }
        .no-data {
            background: white;
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .no-data h2 {
            color: #667eea;
            margin-bottom: 15px;
        }
        .no-data p {
            color: #666;
            font-size: 1.1em;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🧠 PAI 学习仪表板</h1>
            <p>Personal AI Infrastructure - 进化追踪系统</p>
        </div>

        <div class="no-data">
            <h2>🚀 还没有数据</h2>
            <p>开始使用 PAI 学习系统，数据将自动显示在这里！</p>
        </div>
    </div>
</body>
</html>
EOF
    echo "✅ 空仪表板已生成: $DASHBOARD_FILE"
    exit 0
fi

# 收集所有数据
echo "📊 收集学习信号数据..."

# 生成 JSON 数据文件
TEMP_DATA=$(mktemp)
echo "{" > "$TEMP_DATA"
echo "  \"dates\": [" >> "$TEMP_DATA"
echo "  \"taskCounts\": [" >> "$TEMP_DATA"
echo "  \"successRates\": [" >> "$TEMP_DATA"
echo "  \"avgComplexity\": [" >> "$TEMP_DATA"

for file in "${SIGNAL_FILES[@]}"; do
    DATE=$(basename "$file" | sed 's/-signals.jsonl//')
    COUNT=$(wc -l < "$file")
    SUCCESS=$(grep '"success": 1' "$file" | wc -l)
    RATE=$(awk "BEGIN {printf \"%.1f\", ($SUCCESS/$COUNT)*100}")
    COMPLEXITY=$(jq -r '[.complexity] | add / length' "$file" 2>/dev/null || echo "0")

    echo "    \"$DATE\"," >> "$TEMP_DATA"
    echo "    $COUNT," >> "$TEMP_DATA"
    echo "    $RATE," >> "$TEMP_DATA"
    echo "    $COMPLEXITY," >> "$TEMP_DATA"
done

echo "  ]," >> "$TEMP_DATA"
echo "  \"taskTypes\": {" >> "$TEMP_DATA"

# 统计任务类型
DESIGN=$(grep -h '"task_type": "设计"' "${SIGNAL_FILES[@]}" 2>/dev/null | wc -l)
TECH=$(grep -h '"task_type": "技术"' "${SIGNAL_FILES[@]}" 2>/dev/null | wc -l)
LOG=$(grep -h '"task_type": "日志"' "${SIGNAL_FILES[@]}" 2>/dev/null | wc -l)

echo "    \"design\": $DESIGN," >> "$TEMP_DATA"
echo "    \"tech\": $TECH," >> "$TEMP_DATA"
echo "    \"log\": $LOG" >> "$TEMP_DATA"
echo "  }" >> "$TEMP_DATA"
echo "}" >> "$TEMP_DATA"

# 生成仪表板 HTML
cat > "$DASHBOARD_FILE" <<'EOF'
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAI 学习仪表板</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .header {
            background: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .header h1 {
            color: #667eea;
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        .header p {
            color: #666;
            font-size: 1.1em;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card h3 {
            color: #666;
            font-size: 0.9em;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .stat-card .value {
            font-size: 2.5em;
            font-weight: bold;
            color: #667eea;
        }
        .chart-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .chart-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .chart-card h2 {
            color: #667eea;
            margin-bottom: 20px;
            font-size: 1.3em;
        }
        .footer {
            background: white;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            color: #666;
        }
        .update-time {
            color: #999;
            font-size: 0.9em;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🧠 PAI 学习仪表板</h1>
            <p>Personal AI Infrastructure - 进化追踪系统</p>
            <div class="update-time">最后更新: <span id="updateTime"></span></div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>总任务数</h3>
                <div class="value" id="totalTasks">-</div>
            </div>
            <div class="stat-card">
                <h3>平均成功率</h3>
                <div class="value" id="avgSuccess">-</div>
            </div>
            <div class="stat-card">
                <h3>平均复杂度</h3>
                <div class="value" id="avgComplexity">-</div>
            </div>
            <div class="stat-card">
                <h3>积极情感</h3>
                <div class="value" id="positiveRate">-</div>
            </div>
        </div>

        <div class="chart-grid">
            <div class="chart-card">
                <h2>📈 学习曲线</h2>
                <canvas id="learningCurve"></canvas>
            </div>
            <div class="chart-card">
                <h2>🎯 任务类型分布</h2>
                <canvas id="taskTypes"></canvas>
            </div>
        </div>

        <div class="chart-grid">
            <div class="chart-card">
                <h2>✅ 成功率趋势</h2>
                <canvas id="successTrend"></canvas>
            </div>
            <div class="chart-card">
                <h2>📊 复杂度趋势</h2>
                <canvas id="complexityTrend"></canvas>
            </div>
        </div>

        <div class="footer">
            <p>🚀 PAI 学习系统 - 持续进化中</p>
            <p class="update-time">自动更新: 每 5 分钟</p>
        </div>
    </div>

    <script>
        // 设置更新时间
        document.getElementById('updateTime').textContent = new Date().toLocaleString('zh-CN');

        // 这里会加载真实数据
        // TODO: 从后端 API 获取数据
    </script>
</body>
</html>
EOF

echo "✅ 可视化仪表板已生成: $DASHBOARD_FILE"
echo "   访问地址: http://43.134.63.176/pai-dashboard/"

# 清理临时文件
rm -f "$TEMP_DATA"
